package Introduction

class IFExpression {

}
fun main(){

    val number : Int = 1;
    if (number<-0) {
        print("less than 0")
    } else {
        print("more than 0")
    }
}