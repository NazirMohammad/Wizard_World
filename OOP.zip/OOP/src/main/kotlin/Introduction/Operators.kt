package Introduction

class Operators {
}
fun main(args: Array<String>) {

    val numbers = intArrayOf(1, 4, 42, -3)

    if (4 in numbers) {
        println("numbers array contains 4.")
    }

    val number1: Int = 55
    val number2: Long = number1.toLong()   /// type conversion int to long//
    println(number1)


    val number3: Double = 44.4
    val number4: Float = number3.toFloat()
    println(number3)

}
