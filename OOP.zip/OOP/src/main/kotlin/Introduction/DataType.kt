package Introduction

class DataType {

}
      // in kotlin we have Numbers, Arrays , Character and Boolean//

    fun main(args : Array<String>)  {
        val range: Byte = 112 //  byte is 8 bit//
        val size: Short = 12345 // short is 16 bit//
        val journey: Double = 22.5 //hours//
        println(journey)
        println("$size")
        println("$range")

}



