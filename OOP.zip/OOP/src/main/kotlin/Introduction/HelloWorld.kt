package Introduction

    class HelloWorld {
    }
fun main() {
    println("Hello,World")

    var language: String = "French" // dynamic and mutable//
    var lanuage = "German"   // lanuage is variable assigned as var with value German//
    language = "English"
    val score = 95           /// val is immutable once variable assigned  to the value cant be changed//

    val score1 = 95          /// we can have same value assigned but with diffrent variable.//

    println(language)
    println(lanuage)
    println(score)
    println(score1)


}