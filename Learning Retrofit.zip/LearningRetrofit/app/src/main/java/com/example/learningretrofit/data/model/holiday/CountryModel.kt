package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class CountryModel(
    @SerializedName("id")
    val id: String? = "",
    @SerializedName("name")
    val name: String? = ""
)