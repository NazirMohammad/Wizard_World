package com.example.learningretrofit.ui.useless

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.learningretrofit.data.model.UselessFactsModel
import com.example.learningretrofit.data.remote.ApiDetails
import com.example.learningretrofit.data.remote.ApiRequest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class UselessViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is new api Fragment"
    }
    val text: LiveData<String> = _text

    val uselessFact = MutableLiveData<UselessFactsModel>()

    fun getUselessFacts() {
        val result = ApiDetails.getInstanceUseless().create(ApiRequest::class.java)

        GlobalScope.launch {
            val result = result.getUselessFact()
            _text.postValue(result.text.toString())
            uselessFact.postValue(result) // runs when we have the resources
        }

    }

}