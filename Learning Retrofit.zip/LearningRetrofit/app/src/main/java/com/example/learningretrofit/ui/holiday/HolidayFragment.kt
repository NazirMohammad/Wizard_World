package com.example.learningretrofit.ui.holiday

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.learningretrofit.data.model.holiday.HolidayModel
import com.example.learningretrofit.databinding.FragmentHolidayBinding

class HolidayFragment : Fragment() {

    private lateinit var viewModel: HolidayViewModel
    private var _binding: FragmentHolidayBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewModel =
            ViewModelProvider(this)[HolidayViewModel::class.java]
        _binding = FragmentHolidayBinding.inflate(inflater, container, false)

        viewModel.holidays.observe(viewLifecycleOwner) {
            it?.let {
               setupUI(it)
            }
        }

        viewModel.getHolidays()

        return binding.root
    }

    private fun setupUI(holidays: HolidayModel) {
        binding.rvHoliday.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = HolidayAdapter(holidays.response?.holidays)
        }

    }

}