package com.example.learningretrofit.ui.holiday

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.learningretrofit.data.model.DogFactModel
import com.example.learningretrofit.data.model.holiday.HolidayModel
import com.example.learningretrofit.data.remote.ApiDetails
import com.example.learningretrofit.data.remote.ApiRequest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class HolidayViewModel : ViewModel() {
    val holidays = MutableLiveData<HolidayModel>()

    fun getHolidays() {
        val retrofitInstance = ApiDetails.getInstance().create(ApiRequest::class.java)

        GlobalScope.launch {
            val result = retrofitInstance.getHolidays(
                country = "UK",
                year = "2023"
            )
            holidays.postValue(result)
        }

    }
}