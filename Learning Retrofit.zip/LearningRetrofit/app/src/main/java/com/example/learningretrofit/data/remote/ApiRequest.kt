package com.example.learningretrofit.data.remote

import com.example.learningretrofit.data.model.CatFactsModel
import com.example.learningretrofit.data.model.DogFactModel
import com.example.learningretrofit.data.model.DuckImagesModel
import com.example.learningretrofit.data.model.UselessFactsModel
import com.example.learningretrofit.data.model.holiday.HolidayModel
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiRequest {

    @GET(ApiDetails.DOG_FACT)
    suspend fun getDogFact(): DogFactModel

    @GET(ApiDetails.BASE_URL_CATS)
    suspend fun  getCatFact() : CatFactsModel

    @GET(ApiDetails.USELESS_FACT)
    suspend fun  getUselessFact() : UselessFactsModel

    @GET(ApiDetails.DUCKS_IMAGE)
    suspend fun getDucksImage() : DuckImagesModel

    @GET(ApiDetails.HOLIDAYS)
    suspend fun getHolidays(
        @Query("api_key") apiKey: String = "ed0c48c457f181118c83e6bb8de68d5bc396395d",
        @Query("country") country: String,
        @Query("year") year: String
    ) : HolidayModel

}