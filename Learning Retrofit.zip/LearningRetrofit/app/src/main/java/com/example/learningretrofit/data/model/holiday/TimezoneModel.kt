package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class TimezoneModel(
    @SerializedName("offset")
    val offset: String? = "",
    @SerializedName("zoneabb")
    val zoneabb: String? = "",
    @SerializedName("zonedst")
    val zonedst: Int? = 0,
    @SerializedName("zoneoffset")
    val zoneoffset: Int? = 0,
    @SerializedName("zonetotaloffset")
    val zonetotaloffset: Int? = 0
)