package com.example.learningretrofit.data.model

// https://github.com/wh-iterabb-it/meowfacts


import com.google.gson.annotations.SerializedName

data class CatFactsModel(
    @SerializedName("data")
    val `data`: List<String?>? = listOf()
)