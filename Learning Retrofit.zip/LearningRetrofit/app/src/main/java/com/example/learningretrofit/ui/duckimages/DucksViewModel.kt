package com.example.learningretrofit.ui.duckimages

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.learningretrofit.data.remote.ApiDetails
import com.example.learningretrofit.data.remote.ApiRequest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DucksViewModel : ViewModel() {

    private val _img = MutableLiveData<String>()
    private val _url = MutableLiveData<String>().apply {
        value = "Fetching Image"
    }

    val url: LiveData<String> = _url
    val img: LiveData<String> = _img


    fun getDuckImages() {
        val conInstance = ApiDetails.getInstanceDucks().create(ApiRequest::class.java)

        GlobalScope.launch {
            val response = conInstance.getDucksImage()
            _img.postValue(response.url?: "")
            _url.postValue(response.url)

        }

    }


}