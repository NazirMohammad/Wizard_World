package com.example.learningretrofit.ui.catfacts

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.learningretrofit.data.model.CatFactsModel
import com.example.learningretrofit.data.remote.ApiDetails
import com.example.learningretrofit.data.remote.ApiRequest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class CatFactsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is slideshow Fragment"
    }
    val text: LiveData<String> = _text

    val catFact = MutableLiveData<CatFactsModel>()

    fun getCatFacts() {
        val result = ApiDetails.getInstanceCats().create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getCatFact()
            _text.postValue(result.data?.joinToString("\n"))
            catFact.postValue(result) // runs when we have the resources
        }

    }
}