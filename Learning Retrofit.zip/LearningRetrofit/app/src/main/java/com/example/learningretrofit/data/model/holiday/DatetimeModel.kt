package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class DatetimeModel(
    @SerializedName("day")
    val day: Int? = 0,
    @SerializedName("hour")
    val hour: Int? = 0,
    @SerializedName("minute")
    val minute: Int? = 0,
    @SerializedName("month")
    val month: Int? = 0,
    @SerializedName("second")
    val second: Int? = 0,
    @SerializedName("year")
    val year: Int? = 0
)