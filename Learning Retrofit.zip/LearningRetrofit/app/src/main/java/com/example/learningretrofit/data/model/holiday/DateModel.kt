package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class DateModel(
    @SerializedName("datetime")
    val datetime: DatetimeModel? = DatetimeModel(),
    @SerializedName("iso")
    val iso: String? = "",
    @SerializedName("timezone")
    val timezone: TimezoneModel? = TimezoneModel()
)