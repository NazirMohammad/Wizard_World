package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class HolidayModelX(
    @SerializedName("canonical_url")
    val canonicalUrl: String? = "",
    @SerializedName("country")
    val country: CountryModel? = CountryModel(),
    @SerializedName("date")
    val date: DateModel? = DateModel(),
    @SerializedName("description")
    val description: String? = "",
    @SerializedName("locations")
    val locations: String? = "",
    @SerializedName("name")
    val name: String? = "",
    @SerializedName("primary_type")
    val primaryType: String? = "",
//    @SerializedName("states")
//    val states: String? = "",
    @SerializedName("type")
    val type: List<String?>? = listOf(),
    @SerializedName("urlid")
    val urlid: String? = ""
)