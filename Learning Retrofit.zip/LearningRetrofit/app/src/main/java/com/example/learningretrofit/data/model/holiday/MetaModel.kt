package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class MetaModel(
    @SerializedName("code")
    val code: Int? = 0
)