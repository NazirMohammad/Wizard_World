package com.example.learningretrofit.data.model


import com.google.gson.annotations.SerializedName

data class DuckImagesModel(
    @SerializedName("message")
    val message: String? = "",
    @SerializedName("url")
    val url: String? = ""
)