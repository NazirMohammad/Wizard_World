package com.example.learningretrofit.ui.useless

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.learningretrofit.databinding.FragmentUselessBinding

class UselessFragment : Fragment() {

    private var _binding: FragmentUselessBinding? = null
    private val binding get() = _binding!!


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val uselessViewModel =
            ViewModelProvider(this).get(UselessViewModel::class.java)

        _binding = FragmentUselessBinding.inflate(inflater, container, false)

        val textView: TextView = binding.textNewApi
        uselessViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        uselessViewModel.getUselessFacts()

        return binding.root
        }

    }



