package com.example.learningretrofit.ui.duckimages

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.learningretrofit.databinding.FragmentDucksBinding

class DucksFragment : Fragment() {

        private var _binding: FragmentDucksBinding? = null

        // This property is only valid between onCreateView and
        // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val ducksViewModel =
            ViewModelProvider(this).get(DucksViewModel::class.java)

        _binding = FragmentDucksBinding.inflate(inflater, container, false)

        val root: View = binding.root

        val imgView: ImageView = binding.ivDucks
        ducksViewModel.img.observe(viewLifecycleOwner) {
            context?.let { ctx ->
                Glide.with(ctx)
                    .load(it)
                    .into(imgView);
            }
        }

        ducksViewModel.getDuckImages()

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}