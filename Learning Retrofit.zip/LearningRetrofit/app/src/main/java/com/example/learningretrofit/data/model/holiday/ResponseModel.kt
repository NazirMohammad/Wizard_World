package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class ResponseModel(
    @SerializedName("holidays")
    val holidays: List<HolidayModelX>? = listOf()
)