package com.example.learningretrofit.data.model.holiday


import com.google.gson.annotations.SerializedName

data class HolidayModel(
    @SerializedName("response")
    val response: ResponseModel? = ResponseModel()
)