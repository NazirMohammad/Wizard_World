package com.example.learningretrofit.ui.holiday

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.learningretrofit.R
import com.example.learningretrofit.data.model.holiday.HolidayModelX
import com.example.learningretrofit.databinding.ItemHolidayBinding

class HolidayAdapter(val holidays: List<HolidayModelX>?) :
    RecyclerView.Adapter<HolidayAdapter.ViewHolder>() {

    // ITEM/ROW all the settings/UI of individual items
    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        private val binding = ItemHolidayBinding.bind(view)

        fun handleData(item: HolidayModelX?) {
            binding.textView2.text = item?.name
            binding.textView3.text = item?.country?.name
            binding.textView4.text =
                "${item?.date?.datetime?.day}:${item?.date?.datetime?.month}:${item?.date?.datetime?.year}"

            if (adapterPosition % 2 == 0) {
                binding.llHoliday.setBackgroundColor(
                    ContextCompat.getColor(
                        view.context,
                        R.color.purple_200
                    )
                )
            } else {
                binding.llHoliday.setBackgroundColor(
                    ContextCompat.getColor(
                        view.context,
                        R.color.purple_700
                    )
                )
            }
        }

    }

    // Creates the ITEM/ROW for the UI
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolidayAdapter.ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_holiday, parent, false)

        return ViewHolder(view)
    }

    // Size of the list
    override fun getItemCount(): Int = holidays?.size ?: 0

    // Handle the CURRENT item you are on
    override fun onBindViewHolder(holder: HolidayAdapter.ViewHolder, position: Int) {
        holder.handleData(holidays?.get(position))
    }

}
