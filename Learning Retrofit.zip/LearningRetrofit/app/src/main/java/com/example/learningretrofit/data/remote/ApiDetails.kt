package com.example.learningretrofit.data.remote

import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiDetails {

    const val BASE_URL = "https://dog-api.kinduff.com"
    const val DOG_FACT = "/api/facts"
    const val BASE_URL_CATS = "https://meowfacts.herokuapp.com"
    const val BASE_URL_USELESS = "https://uselessfacts.jsph.pl/"
    const val USELESS_FACT = "api/v2/facts/random"
    const val BASE_URL_DUCKS = "https://random-d.uk/"
    const val DUCKS_IMAGE = "/api/v2/random"
    const val HOLIDAYS =
        "https://calendarific.com/api/v2/holidays"
    //?&api_key=ed0c48c457f181118c83e6bb8de68d5bc396395d&country=US&year=2019"

    val client = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    fun getInstance(): Retrofit =
        Retrofit.Builder()//its pattern that helps build an object with different properties
            .baseUrl(BASE_URL) // setting the common BASE url for all
            .addConverterFactory(GsonConverterFactory.create(Gson())) //Convert your JSON data to Data class
            .client(client)
            .build() // finalize the object/builder

    fun getInstanceCats(): Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL_CATS)
        .addConverterFactory(GsonConverterFactory.create(Gson()))
        .build()

    fun getInstanceUseless(): Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL_USELESS)
        .addConverterFactory(GsonConverterFactory.create(Gson()))
        .build()

    fun getInstanceDucks(): Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL_DUCKS)
        .addConverterFactory(GsonConverterFactory.create(Gson()))
        .build()

}