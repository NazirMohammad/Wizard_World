package com.example.learningretrofit.ui.dogfacts

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.learningretrofit.data.model.DogFactModel
import com.example.learningretrofit.data.remote.ApiDetails
import com.example.learningretrofit.data.remote.ApiRequest
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class DogFactsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text


    val dogFact = MutableLiveData<DogFactModel>()

    fun getDogFacts() {
        val result = ApiDetails.getInstance().create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getDogFact()
            _text.postValue(result.facts?.joinToString("\n"))
            dogFact.postValue(result) // runs when we have the resources
        }

    }
}