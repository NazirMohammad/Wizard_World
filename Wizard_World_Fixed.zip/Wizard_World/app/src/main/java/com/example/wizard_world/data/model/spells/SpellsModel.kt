package com.example.wizard_world.data.model.spells


import com.google.gson.annotations.SerializedName

class SpellsModel : ArrayList<SpellsModelItemModel>()