package com.example.wizard_world.data.remote

object ApiDetails {

    const val BASE_URL = "https://wizard-world-api.herokuapp.com/"
    const val Elixirs = "Elixirs/"
    const val feedback = "Feedback/"
    const val Houses = "Houses/"
    const val Spells = "Spells/"
    const val Wizard = "Wizards/"

}


