package com.example.wizard_world.ui.elixirs

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.example.wizard_world.R
import com.example.wizard_world.data.model.elixirs.ElixirModel
import com.example.wizard_world.databinding.FragmentElixirsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ElixirsFragment : Fragment() {

    private var _binding: FragmentElixirsBinding? = null
    private val binding get() = _binding!!

    private val viewModel by viewModels<ElixirsViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

        _binding= FragmentElixirsBinding.inflate(inflater,container, false)

        return binding.root
    }

}