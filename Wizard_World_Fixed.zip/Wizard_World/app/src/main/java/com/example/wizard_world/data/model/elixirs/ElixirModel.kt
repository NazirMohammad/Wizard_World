package com.example.wizard_world.data.model.elixirs


import com.google.gson.annotations.SerializedName

class ElixirModel : ArrayList<ElixirModelItemModel>()