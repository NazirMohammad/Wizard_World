package com.example.starwarstrivia.ui.people

import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.starwarstrivia.R
import com.example.starwarstrivia.data.model.people.PeopleResultModel
import com.example.starwarstrivia.databinding.ItemPeopleBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel

class PeopleAdapter(val people: List<PeopleResultModel>?) :
    RecyclerView.Adapter<PeopleAdapter.ViewHolder>() {

    // ITEM/ROW all the settings/UI of individual items
    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        private val binding = ItemPeopleBinding.bind(view)

        fun handleData(item: PeopleResultModel?) {
            binding.tvName.text = item?.name
        }

    }

    // Creates the ITEM/ROW for the UI
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeopleAdapter.ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_people, parent, false)

        return ViewHolder(view)
    }

    // Size of the list
    override fun getItemCount(): Int = people?.size ?: 0

    // Handle the CURRENT item you are on
    override fun onBindViewHolder(holder: PeopleAdapter.ViewHolder, position: Int) {
        holder.handleData(people?.get(position))
    }

}
