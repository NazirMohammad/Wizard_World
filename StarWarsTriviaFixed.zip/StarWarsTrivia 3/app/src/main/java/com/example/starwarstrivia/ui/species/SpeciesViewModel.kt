package com.example.starwarstrivia.ui.species

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.starwarstrivia.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SpeciesViewModel @Inject constructor(
    val repository: Repository
): ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = "This is Species Fragment"
    }
    val text: LiveData<String> = _text

    fun getSpeciesModel() {
        viewModelScope.launch {
            val result = repository.getSpecies()
            _text.postValue(result.results?.toString())
            //people.postValue(result)
        }
    }

}