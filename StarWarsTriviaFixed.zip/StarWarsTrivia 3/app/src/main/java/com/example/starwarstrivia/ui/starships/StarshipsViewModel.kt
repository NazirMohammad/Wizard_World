package com.example.starwarstrivia.ui.starships

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.starwarstrivia.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StarshipsViewModel @Inject constructor(
    val repository: Repository
): ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Starships Fragment"
    }
    val text: LiveData<String> = _text

    fun getStarshipsModel() {
        viewModelScope.launch {
            val result = repository.getStarships()
            _text.postValue(result.results?.toString())
            //people.postValue(result)
        }
    }
}