package com.example.starwarstrivia.ui.vehicles

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.starwarstrivia.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VehiclesViewModel @Inject constructor(
    val repository: Repository
): ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = "This is Vehicles Fragment"
    }
    val text: LiveData<String> = _text

    fun getVehiclesModel() {
        viewModelScope.launch {
            val result = repository.getVehicles()
            _text.postValue(result.results?.toString())
            //people.postValue(result)
        }
    }
}