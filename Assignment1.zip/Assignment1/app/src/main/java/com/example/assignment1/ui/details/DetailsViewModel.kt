package com.example.assignment1.ui.details

import androidx.lifecycle.ViewModel

class DetailsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}