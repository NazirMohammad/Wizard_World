package com.example.assignment1.ui.rates

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.assignment1.coincapapi.ApiDetails
import com.example.assignment1.coincapapi.ApiRequest
import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.coincapapi.model.rate.RatesModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class RateViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text

    val rates = MutableLiveData<RatesModel>()

    fun getRates() {
        val result = ApiDetails.getInstanceRates(ApiDetails.BASE_Rates).create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getRates()
            _text.postValue(result.data?.joinToString("\n"))
            rates.postValue(result) // runs when we have the resources
        }

    }
}