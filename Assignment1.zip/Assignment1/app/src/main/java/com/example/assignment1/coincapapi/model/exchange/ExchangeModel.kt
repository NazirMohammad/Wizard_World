package com.example.assignment1.coincapapi.model.exchange


import com.google.gson.annotations.SerializedName

data class ExchangeModel(
    @SerializedName("data")
    val `data`: List<DataModel?>? = listOf(),
    @SerializedName("timestamp")
    val timestamp: Long? = 0
)