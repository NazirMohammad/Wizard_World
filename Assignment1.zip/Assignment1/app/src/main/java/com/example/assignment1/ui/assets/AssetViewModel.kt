package com.example.assignment1.ui.assets

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.assignment1.coincapapi.ApiDetails
import com.example.assignment1.coincapapi.ApiRequest
import com.example.assignment1.coincapapi.model.asset.AssetModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class AssetViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is gallery Fragment"
    }
    val text: LiveData<String> = _text



    val assets = MutableLiveData<AssetModel>()

    fun getAssets() {
        val result = ApiDetails.getInstance(ApiDetails.BASE_URL).create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getAssets(
                Rank = "Two",
            Name= "Bitcoin"

            )
            _text.postValue(result.data?.joinToString("\n"))
            assets.postValue(result) // runs when we have the resources
        }

    }

}