package com.example.assignment1.ui.exchange

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.R
import com.example.assignment1.coincapapi.model.exchange.DataModel
import com.example.assignment1.databinding.ItemExchangeBinding

class ExchangeAdapter(exchange: DataModel) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        private val binding = ItemExchangeBinding.bind(view)

        fun handleData(item: DataModel?) {
            binding.textView2.text = item?.name





            }
        }

    }

    // Creates the ITEM/ROW for the UI
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExchangeAdapter.ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_exchange, parent, false)

        return ExchangeAdapter.ViewHolder(view)
    }

    // Size of the list
    override fun getItemCount(): Int = exchange?.size ?: 0

    // Handle the CURRENT item you are on
    override fun onBindViewHolder(holder: ExchangeAdapter.ViewHolder, position: Int) {
        holder.handleData(exchange?.get(position))
    }
}

}
