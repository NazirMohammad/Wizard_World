package com.example.assignment1.ui.assets

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment1.R
import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.databinding.ItemAssetsBinding


class AssetsAdapter(val asset: AssetModel?) :
    RecyclerView.Adapter<AssetsAdapter.ViewHolder>() {


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
       private val binding = ItemAssetsBinding.bind(view)

//        fun handleData(item:AssetModel) {
//        binding.llasset
//        }
//    }





        fun handleData(item: AssetModel?) {
            binding.textView2.text=item.toString()
            binding.textView3.text=item.toString()
            binding.textView4.text=item.toString()

        }

        }
//            item?.let {
//                with(it) {
//
//
//                }
//            }
//        }
//    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AssetsAdapter.ViewHolder {
        //creates item/row for the UI

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_assets, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int = asset?.data?.size ?: 0
    //size of the list


    override fun onBindViewHolder(holder: AssetsAdapter.ViewHolder, position: Int) {
        //handle the current item u r on
        val rdModel = asset?.data?.get(position)
        holder?.handleData(AssetModel())
    }

}