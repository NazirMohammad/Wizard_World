package com.example.assignment1.ui.exchange

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.coincapapi.model.exchange.DataModel
import com.example.assignment1.coincapapi.model.exchange.ExchangeModel
import com.example.assignment1.databinding.FragmentGalleryBinding
import com.example.assignment1.databinding.FragmentSlideshowBinding
import com.example.assignment1.ui.assets.AssetViewModel
import com.example.assignment1.ui.assets.AssetsAdapter

class ExchangeFragment : Fragment() {

    private lateinit var viewModel1: ExchangeViewModel
    private var _binding: FragmentSlideshowBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {


        viewModel1 =
            ViewModelProvider(this)[ExchangeViewModel::class.java]
        _binding = FragmentSlideshowBinding.inflate(inflater, container, false)

        viewModel1.exchange.observe(viewLifecycleOwner) {
            it?.let {
                setupUI(it)
            }
        }

        viewModel1.getExchange()

        return binding.root
    }

    private fun setupUI(exchange:ExchangeModel){
    binding.textSlideshow.apply {
        layoutManager = LinearLayoutManager(context)
        adapter = ExchangeAdapter(DataModel())
    }}
}

//        val slideshowViewModel =
//            ViewModelProvider(this).get(ExchangeViewModel::class.java)
//
//
//        _binding = FragmentSlideshowBinding.inflate(inflater, container, false)
//        val root: View = binding.root
//
//        val textView: TextView = binding.textSlideshow
//        slideshowViewModel.text.observe(viewLifecycleOwner) {
//            textView.text = it
//
//
//        }


//
//        slideshowViewModel.getExchange()
//
//        return root
//    }
//
//
//    override fun onDestroyView() {
//        super.onDestroyView()
//        _binding = null
//
//
//    }
//}