package com.example.assignment1.ui.market

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.assignment1.coincapapi.ApiDetails
import com.example.assignment1.coincapapi.ApiRequest
import com.example.assignment1.coincapapi.model.market.MarketModel
import com.example.assignment1.coincapapi.model.rate.RatesModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MarketViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text

    val market = MutableLiveData<MarketModel>()

    fun getMarket() {
        val result = ApiDetails.getInstanceMarket(ApiDetails.BASE_Market).create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getMarket()
            _text.postValue(result.data?.joinToString("\n"))
            market.postValue(result) // runs when we have the resources
        }

    }
}
