package com.example.assignment1.ui.assets

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.databinding.FragmentGalleryBinding
import kotlin.time.Duration.Companion.days

class AssetFragment : Fragment() {

    private lateinit var viewModel: AssetViewModel
    private var _binding: FragmentGalleryBinding? = null
    private val binding get() = _binding!!


    // This property is only valid between onCreateView and
    // onDestroyView.


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,

        ): View {
        viewModel =
            ViewModelProvider(this)[AssetViewModel::class.java]

        _binding = FragmentGalleryBinding.inflate(inflater, container, false)

        viewModel.assets.observe(viewLifecycleOwner) {
            it?.let {
                setupUI(it)


            }
        }


//        val galleryViewModel =
//            ViewModelProvider(this).get(AssetViewModel::class.java)
//
//        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
//        val root: View = binding.root
//
//        val textView: TextView = binding.textGallery
//        galleryViewModel.text.observe(viewLifecycleOwner) {
//            textView.text = it
//        }
//
//        galleryViewModel.getAssets()


        viewModel.getAssets()

        return binding.root
    }

    private fun setupUI(assets: AssetModel) {
        binding.rvGallery.apply {
            layoutManager=LinearLayoutManager(context)
            adapter = AssetsAdapter(assets)
        }

    }




        }



//    override fun onDestroyView() {
//        super.onDestroyView()
//        _binding = null
//    }
//}