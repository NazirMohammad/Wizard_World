package com.example.assignment1.ui.exchange

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.assignment1.coincapapi.ApiDetails
import com.example.assignment1.coincapapi.ApiRequest
import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.coincapapi.model.exchange.ExchangeModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class ExchangeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is slideshow Fragment"
    }
    val text: LiveData<String> = _text

    val exchange = MutableLiveData<ExchangeModel>()

    fun getExchange() {
        val result = ApiDetails.getInstanceExchange(ApiDetails.BASE_Exchange).create(ApiRequest::class.java)

        GlobalScope.launch {
//            dogFact.value  = result.getDogFact() // forces it / runs on priority
            val result = result.getExchange()
            _text.postValue(result.data?.joinToString("\n"))
            exchange.postValue(result) // runs when we have the resources
        }

    }


}