package com.example.assignment1.coincapapi

import com.example.assignment1.coincapapi.model.asset.AssetModel
import com.example.assignment1.coincapapi.model.exchange.ExchangeModel
import com.example.assignment1.coincapapi.model.market.MarketModel
import com.example.assignment1.coincapapi.model.rate.RatesModel
import retrofit2.http.GET
import retrofit2.http.Query
import java.nio.channels.spi.AbstractSelectionKey

interface ApiRequest {
    @GET(ApiDetails.Base_Asset)
    suspend fun getAssets(
        @Query("api_key") apiKey: String = "v2/assets/" ,
        @Query("rank ") Rank:String,
        @Query("name ") Name:String,

    ): AssetModel



    @GET(ApiDetails.BASE_Rates)
    suspend fun getRates(): RatesModel

    @GET(ApiDetails.BASE_Exchange)
    suspend fun getExchange(): ExchangeModel


    @GET(ApiDetails.BASE_Market)
    suspend fun getMarket(): MarketModel
}