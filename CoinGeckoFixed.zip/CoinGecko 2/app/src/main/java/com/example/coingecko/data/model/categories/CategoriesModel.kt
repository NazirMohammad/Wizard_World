package com.example.coingecko.data.model.categories


class CategoriesModel : ArrayList<CategoriesItemModel>()