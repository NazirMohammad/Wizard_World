package com.example.coingecko.data.model.exchanges


class ExchangesModel : ArrayList<ExchangesItemModel>()