package com.example.coingecko.data.model.coin


import com.google.gson.annotations.SerializedName

class coins : ArrayList<coinsItemModel>()