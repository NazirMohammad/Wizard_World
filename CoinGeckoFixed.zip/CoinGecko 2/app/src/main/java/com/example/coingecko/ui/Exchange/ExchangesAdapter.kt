package com.example.coingecko.ui.Exchange

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coingecko.R
import com.example.coingecko.data.model.categories.CategoriesItemModel
import com.example.coingecko.data.model.categories.CategoriesModel
import com.example.coingecko.data.model.exchanges.ExchangesItemModel
import com.example.coingecko.data.model.exchanges.ExchangesModel
import com.example.coingecko.databinding.ItemCategoriesBinding
import com.example.coingecko.databinding.ItemExchangeBinding
import com.example.coingecko.ui.categories.CategoriesAdapter
import kotlinx.coroutines.NonDisposableHandle.parent

class ExchangesAdapter (val exchanges: ExchangesModel):
    RecyclerView.Adapter<ExchangesAdapter.ViewHolder>(){
    var onItemClick: ((ExchangesItemModel)-> Unit)?= null

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val binding= ItemExchangeBinding.bind(view)

        fun handleData(item: ExchangesItemModel?){
            item?.let {
                binding.textView2.text = item?.id
                binding.textView3.text = item?.name
                // binding.textView4.text = item?.content
            }
        }
    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ExchangesAdapter.ViewHolder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.item_exchange, parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExchangesAdapter.ViewHolder, position: Int) {
        holder.handleData(exchanges?.get(position))
        holder.itemView.setOnClickListener{
            exchanges?.get(position)?.let {
                onItemClick?.invoke(it)
            }
        }
    }

    override fun getItemCount(): Int = exchanges?.size?:0


}