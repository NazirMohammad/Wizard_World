package com.example.coingecko.ui.Exchange.exchangedetail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.coingecko.data.model.exchangedetail.ExchangeDetailModel
import com.example.coingecko.data.model.exchanges.ExchangesModel
import com.example.coingecko.data.repository.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class ExchangeDetailViewModel @Inject constructor(
    val repository: Repository
): ViewModel() {
    val exchangeDetails= MutableLiveData<ExchangeDetailModel>()


    fun getExchangeDetails(exchangeId:String)
    {
        viewModelScope.launch {
            val result=repository.getExchangeDetails(exchangeId)
            exchangeDetails.postValue(result)
        }
    }


}